iPhone系统浏览器UA：
<textarea>Mozilla/5.0 (iPhone; CPU iPhone OS 5_1 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B176 Safari/7534.48.3</textarea>

安卓系统浏览器UA：
<textarea>Mozilla/5.0 (Linux; U; Android 4.0.4; zh-cn; sdk Build/MR1)AppleWebKit/534.31 (KHTML, like Gecko) Mobile Safari/534.30</textarea>

iPad系统浏览器UA：
<textarea>Mozilla/5.0 (iPad; U; CPU  OS 4_1 like Mac OS X; en-us)AppleWebKit/532.9(KHTML, like Gecko) Version/4.0.5 Mobile/8B117 Safari/6531.22.7</textarea>

Windows IE浏览器UA：
<textarea>Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)</textarea>

Firefox浏览器UA：
<textarea>Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-cn; rv:1.9.2.4410) Gecko/20110902 Firefox/3.6</textarea>

Nokia低端机UA：
<textarea>MQQBrowser/Mini3.1 (Nokia3050/MIDP2.0) Via: MQQBrowser</textarea>

Baiduspider UA：
<textarea>Baiduspider+(+http://www.baidu.com/search/spider.htm)</textarea>