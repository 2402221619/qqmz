<?php
//Ajax入口文件
define('AJAX_INT', true);
$mod=isset($_GET['mod'])?$_GET['mod']:null;
include("./includes/common.php");
?>