<?php
error_reporting(0);
@header("Content-Type: text/html; charset=UTF-8");
$uin = $_POST["uin"];
$ssid = $_POST["ssid"];
$touin = $_POST["touin"];
$content = $_POST["content"];
if(!$uin||!$ssid||!$touin||!$content)exit;

$cookie_file='../cookie/'.$ssid.'.txt';

$uins=explode(',',$touin);

require_once '../webqq.class.php';
$qzone=new webqq($uin);
$qzone->cookie=file_get_contents($cookie_file);

$dxrow['code']=0;
$dxrow['msg']='suc';
$msgid=34080001;
foreach($uins as $touin){
	if(!$touin)continue;

	$res = $qzone->send_buddy_msg($touin, $content, $msgid);
	if ($res == true)$result=array('touin'=>$touin,'is'=>'1');
	else $result=array('touin'=>$touin,'is'=>'0');
	$msgid++;

	$dxrow['data'][]=$result;
}
exit(json_encode($dxrow));
?>
