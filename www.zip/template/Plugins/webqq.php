<?php
if(!defined('IN_CRONLITE'))exit();

$title='WEBQQ扫码登录';
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist">ＱＱ管理</a></li>
<li><a href="index.php?mod=list-qq&qq='.$_GET['qq'].'">'.$_GET['qq'].'</a></li>
<li class="active"><a href="#">WEBQQ扫码登录</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-lg-6 col-md-8 col-sm-10 col-xs-12 center-block" role="main">
<script>

</script>';

if($islogin==1){
vipfunc_check('aite');
$act=isset($_GET['act'])?$_GET['act']:null;

$qq=isset($_GET['qq'])?daddslashes($_GET['qq']):null;
if(!$qq) {
	showmsg('参数不能为空！');
}
?>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">WEBQQ扫码登录</h3></div>
<div class="panel-body" style="text-align: center;">
<input type="hidden" id="uin" value="<?php echo $qq ?>"/>
		<div class="list-group">
			<div class="list-group-item list-group-item-info" style="font-weight: bold;" id="login">
				<span id="loginmsg">使用QQ手机版扫描二维码</span><span id="loginload" style="padding-left: 10px;color: #790909;">.</span>
			</div>
			<div class="list-group-item" id="qrimg">
			</div>
			<div class="list-group-item" id="mobile" style="display:none;"><button type="button" id="mlogin" onclick="mloginurl()" class="btn btn-warning btn-block">跳转QQ快捷登录</button><br/><button type="button" onclick="loadScript()" class="btn btn-success btn-block">我已完成登录</button></div>
		</div>
</div></div>
<script src="qq/getsid/webqq.js?v=<?php echo VERSION ?>"></script>
<?php
}else{
showmsg('登录失败，可能是密码错误或者身份失效了，请<a href="index.php?mod=login">重新登录</a>！',3);
}

include TEMPLATE_ROOT."foot.php";
?>