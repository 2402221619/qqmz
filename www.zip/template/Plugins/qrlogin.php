<?php
if(!defined('IN_CRONLITE'))exit();

$image=trim($_POST['image']);
$data=get_curl('http://qr.flyqy.cn/AddQQ_Ajax.php?image='.urlencode($image));
$arr=json_decode($data,true);
if($arr['code']==1) {
	exit('{"code":0,"msg":"succ","url":"'.$arr['url'].'"}');
}elseif(array_key_exists('msg',$arr)){
	exit('{"code":-1,"msg":"'.$arr['msg'].'"}');
}else{
	exit('{"code":-1,"msg":"'.$data.'"}');
}

?>