﻿<?php 
if($islogin==1)exit("<script language='javascript'>window.location.href='./index.php?mod=user';</script>");
$title='用户登录';
include_once(TEMPLATE_ROOT."head2.php");
?>
<div class="yunyan_box">
      <div class="yunyan_logo">
        <i class="fa fa-thumbs-up"></i>
        <strong><?php echo $conf['sitename']?></strong></div>
      <form action="?" method="get">
		<input type="hidden" name="my" value="login">
        <input name="user" placeholder="请输入您注册时填写的账号" type="text" value="" required="" data-form-un="1489318801757.5786">
        <hr class="hr15">
        <input name="pass" placeholder="请输入您注册时填写的密码" type="password" value="" required="" data-form-pw="1489318801757.5786">
        <hr class="hr15">
        <input href="index.html" value="登录" name="submit" style="opacity: 1; pointer-events: auto;" type="submit" data-form-sbm="1489318801757.5786">
        <hr class="hr20">
        <input type="checkbox" name="ctime" id="ctime" class="chk_3" checked="checked" value="2592000">
        <label for="ctime"></label>
        <font color="18px">下次自动登录</font>
        <hr class="new">
		<div class="text-with-hr">
		</div>
		<div class="bk-margin-bottom-10 bk-margin-top-10 text-center">
									<?php if($conf['oauth_open']){
			$oauth_option=explode("|",$conf['oauth_option']);
			if(in_array('qqdenglu',$oauth_option))echo '<a href="social.php?type=qqdenglu"><img src="assets/img/social/qqdenglu.png"></a>&nbsp;';
			if(in_array('baidu',$oauth_option))echo '<a href="social.php?type=baidu"><img src="assets/img/social/baidu.png"></a>&nbsp;';
			if(in_array('sinaweibo',$oauth_option))echo '<a href="social.php?type=sinaweibo"><img src="assets/img/social/sinaweibo.png"></a>&nbsp;';
			if(in_array('qqweibo',$oauth_option))echo '<a href="social.php?type=qqweibo"><img src="assets/img/social/qqweibo.png"></a>&nbsp;';
			if(in_array('renren',$oauth_option))echo '<a href="social.php?type=renren"><img src="assets/img/social/renren.png"></a>&nbsp;';
			if(in_array('kaixin',$oauth_option))echo '<a href="social.php?type=kaixin"><img src="assets/img/social/kaixin.png"></a>&nbsp;';
		}?>
		</div>
		<br>
        <div class="row push">
          <div class="col-xs-6">
            <a href="index.php?mod=reg" class="btn btn-sm btn-info btn-block">
              <i class="fa fa-plus-circle"></i> 注册账号</a>
          </div>
          <div class="col-xs-6">
            <a href="index.php?mod=findpwd" class="btn btn-sm btn-primary btn-block">
              <i class="fa fa-info-circle"></i> 忘记密码</a>
          </div>
        </div>
      </form>
    </div>
	</body>
	</html>