﻿<?php
if(!defined('IN_CRONLITE'))exit();
@header('Content-Type: text/html; charset=UTF-8');

$sitename=$conf['sitename'];

if($title=='首页' || empty($title))
$titlename=$sitename.' '.$conf['sitetitle'];
else
$titlename=$title.'|'.$sitename.' '.$conf['sitetitle'];

?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="charset" content="utf-8">
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title><?php echo $titlename?></title>
<meta name="keywords" content="<?php echo $conf['keywords']?>" />
<meta name="description" content="<?php echo $conf['description']?>" />
<link rel="shortcut icon" href="images/favicon.ico">
	<link href="<?php echo $cdnserver?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo $cdnserver?>assets/css/login.css" rel="stylesheet" >
    <link href="<?php echo $cdnserver?>assets/css/alert.css" rel="stylesheet" />
    <script src="<?php echo $cdnserver?>assets/vendor/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo $cdnserver?>assets/js/alert.js"></script>
</head>
<body>