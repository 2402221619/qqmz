<div class="modal fade" align="left" id="shop" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" onclick="clearInterval(interval1)"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">在线支付</h4>
      </div>
      <div class="modal-body">
<?php
if(!defined('IN_CRONLITE'))exit();

$act=isset($_GET['act'])?$_GET['act']:null;

if($islogin==1)
{
switch($act) {
case 'pay':
	$type=isset($_GET['type'])?daddslashes($_GET['type']):exit('No paytype!');
	$shopid=isset($_GET['shopid'])?daddslashes($_GET['shopid']):exit('No shopid!');
	$qq=isset($_GET['qq'])?daddslashes($_GET['qq']):null;
	$money=$buy_rules[$shopid];
	if($shopid>=10&&$shopid<=11)$money=$qq;
	elseif($shopid==12)$money=$daili_rules[10];
	if($shopid==0)$name='1天试用VIP会员';elseif($shopid==1)$name='1个月VIP会员';elseif($shopid==2)$name='3个月VIP会员';elseif($shopid==3)$name='6个月VIP会员';elseif($shopid==4)$name='12个月VIP会员';elseif($shopid==5)$name='永久VIP会员';elseif($shopid==6)$name='1个QQ配额';elseif($shopid==7)$name='3个QQ配额';elseif($shopid==8)$name='5个QQ配额';elseif($shopid==9)$name='10个QQ配额';elseif($shopid==10)$name=($qq*$rules[0]).$conf['coin_name'];elseif($shopid==11)$name='代理余额'.$qq.'元';elseif($shopid==12)$name='开通代理商';
	$name.='-UID:'.$uid;

	if($money<=0)exit('该商品未出售！');
?>
<?php
if($type == 'alipay')$typename = '支付宝';
elseif($type == 'tenpay')$typename = '财付通';
elseif($type == 'qqpay')$typename = 'QQ钱包';
elseif($type == 'wxpay')$typename = '微信支付';

	$orderid=date("YmdHis").rand(111,999);
	$sql="insert into `".DBQZ."_pay` (`uid`,`qq`,`type`,`orderid`,`addtime`,`shopid`,`name`,`money`,`status`) values ('".$uid."','".$qq."','".$type."','".$orderid."','".$date."','".$shopid."','".$name."','".$money."','0')";
	if($DB->query($sql))
		echo '<table class="table"><tobdy><tr><td><font color="green">已经成功生成订单！</font></td></tr><tr><td>订单号：<u>'.$orderid.'</u></td></tr><tr><td>商品名称：<u>'.$name.'</u></td></tr><tr><td>订单金额：<u><b>'.$money.'</b>元</u></td></tr><tr><td>支付方式：<u>'.$typename.'</u></td></tr><tr><td><a href="index.php?mod=pay&type='.$type.'&orderid='.$orderid.'" class="btn btn-success btn-block" target="_blank">立即支付</a></td></tr></tbody></table>';
	else
		echo '<table class="table"><tobdy><tr><td>生成订单失败！</td></tr><tr><td>原因：'.$DB->error().'</td></tr></tbody></table>';

break;
}

}else{
	exit('登录失败，可能是密码错误或者身份失效了，请重新登录！');
}
?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="clearInterval(interval1)">Close</button>
      </div>
    </div>
  </div>
</div>