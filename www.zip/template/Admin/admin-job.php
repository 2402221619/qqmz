<?php
if(!defined('IN_CRONLITE'))exit();
$title="任务数据管理";

$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=admin"><i class="icon fa fa-cog"></i>后台管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-list-alt"></i>任务数据管理</a></li>';
include TEMPLATE_ROOT."head.php";

echo '<div class="col-md-12" role="main">';

$table=isset($_GET['table'])?$_GET['table']:'wzjob';
$sysid=isset($_GET['sys'])?$_GET['sys']:1;

if ($isadmin==1)
{

if(isset($_GET['kw'])) {
	$sql=" `url` LIKE '%{$_GET['kw']}%'";
	$link='&table=wzjob&kw='.$_GET['kw'];
	$rownum='包含'.$_GET['kw'].'的共有';
}
elseif($conf['server_wz']>1 && $table=='wzjob') {
	$sql=" sysid='{$sysid}'";
	$link='&table=wzjob&sys='.$sysid;
	$rownum='系统'.$sysname[$sysid].'下共有';
}
else {
	$sql=' 1';
	$link='&table='.$table;
}

$zongs=$DB->count("select count(*) from ".DBQZ."_{$table} where 1");
echo '<h3>任务数据管理</h3>';
echo '<div class="alert alert-info">网站共有'.$zongs.'条任务';
if($conf['server_wz']>1 && $table=='wzjob'){
	echo '<br>【';
	for($i=1;$i<=$conf['server_wz'];$i++)
		echo '<a href="index.php?mod=admin-job&sys='.$i.'">系统'.$sysname[$i].'</a>.';
	echo '】<br>';
}

$numrows=$DB->count("select count(*) from ".DBQZ."_{$table} where".$sql);
if(isset($rownum))echo $rownum.$numrows.'条任务';
if(isset($_GET['kw']))echo '<br>[<a href="index.php?mod=admin-clear&my=qlrw&table='.$table.'&kw='.urlencode($_GET['kw']).'">删除所有包含'.$_GET['kw'].'的任务</a>]';
echo '</div>';

$pagesize=$conf['pagesize'];
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

?>
<script>
function showresult(surl) {
  htmlobj=$.ajax({url:"template/Ajax/display.php?list=8&url="+surl,async:false});
  $("#myDiv").html(htmlobj.responseText);
}
function job_edit(act,jobid,table,page) {
	page = page || 1;
	if(act=='del') {
		if(!confirm('你确实要删除此任务吗？'))return false;
	}
	ajax.get("ajax.php?mod=edit&act="+act+"&jobid="+jobid+"&table="+table, "json", function(arr) {
		if(arr.code==1){
			alert(arr.msg);
			showlist('qqtask',page);
		}else{
			alert(arr.msg);
		}
	});
	document.location.reload();
}
</script>

<style>
.table-responsive>.table>tbody>tr>td,.table-responsive>.table>tbody>tr>th,.table-responsive>.table>tfoot>tr>td,.table-responsive>.table>tfoot>tr>th,.table-responsive>.table>thead>tr>td,.table-responsive>.table>thead>tr>th{white-space: pre-wrap;}
</style>
<div class="panel panel-default table-responsive">
<table class="table table-hover">
	<thead>
		<tr>
			<th>任务名称/网址</th>
			<th>其他信息</th>
			<th>状态/操作</th>
		</tr>
	</thead>
	<tobdy>
<?php

$rs=$DB->query("select * from ".DBQZ."_{$table} where{$sql} order by jobid desc limit $offset,$pagesize");
$i=0;
while($myrow = $DB->fetch($rs))
{
	$i++;
	$pagesl = $i + ($page - 1) * $pagesize;
	
	if($table=='wzjob'){
		echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$myrow['name'].'</b><br/>建立者:<a href="index.php?mod=admin-user&my=user&uid='.$myrow['uid'].'">UID:'.$myrow['uid'].'</a><br/>';
		echo '<a href="'.$myrow['url'].'" target="_blank">'.$myrow['url'].'</a><br>';
		if(!empty($myrow['realip']))echo '{真实IP:'.$myrow['realip'].'}';
		if($myrow['usep']==1)echo '{代理IP}';
		if($myrow['post']==1)echo '{模拟POST}';
		if($myrow['cookie']!='')echo '{模拟Cookie}';
		if($myrow['referer']!='')echo '{模拟来源}';
		if($myrow['useragent']!='')echo '{模拟浏览器}';
	}elseif($table=='qqjob'){
		$type=$myrow['type'];
		$qqjob=qqjob_decode($myrow['qq'],$type,$myrow['method'],$myrow['data']);
		echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$qqTaskNames[$type].'任务</b><br/>建立者:<a href="index.php?mod=admin-user&my=user&uid='.$myrow['uid'].'">UID:'.$myrow['uid'].'</a><br/>'.$qqjob['info'];
	}elseif($table=='signjob'){
		$type=$myrow['type'];
		$signjob=signjob_decode($type,$myrow['data']);
		echo '<tr jobid="'.$myrow['jobid'].'"><td style="width:40%;"><b>'.$pagesl.'.'.$signTaskNames[$type].'任务</b><br/>建立者:<a href="index.php?mod=admin-user&my=user&uid='.$myrow['uid'].'">UID:'.$myrow['uid'].'</a><br/>签到数据：'.$signjob['data'].$signjob['info'];
	}

	echo '</td><td style="width:35%">状态:';
	if ($myrow['zt'] == '1'){
		echo '<font color="red">暂停运行...</font><br/>';
	}else{
		echo '<font color="green">正在运行</font><br/>';
	}
	echo '运行次数:<font color="red">'.$myrow['times'].'</font><br>上次执行:<font color="blue">'.dgmdate($myrow['lasttime']).'</font><br/>运行时间:<font color="blue">';
	echo $myrow['start'].'时 - '.$myrow['stop'].'时</font>';
	if($myrow['pl']!=0)
		echo '<br>运行频率:<font color="red">'.$myrow['pl'].'</font>秒/次';
	elseif(in_array($type,$qqSignTasks))
		echo '<br>运行频率:<font color="red">18000</font>秒/次';
	elseif(in_array($type,$qqLimitTasks) || in_array($type,$qqGuajiTasks))
		echo '<br>运行频率:<font color="red">600</font>秒/次';

	echo '</td><td style="width:25%">';
	if($myrow['data'] || $table=='wzjob')
		echo '<a href="#" onclick="'.$table.'_edit(\'edit\',\''.$myrow['jobid'].'\',\''.$myrow['sysid'].'\',\''.$page.'\')" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp;编辑</a><br/>';
	if ($myrow['zt'] == '1') {
		echo '<a href="#" onclick="job_edit(\'kq\','.$myrow['jobid'].',\''.$table.'\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-play"></i>&nbsp;开启</a>';
	}else{
		echo '<a href="#" onclick="job_edit(\'zt\','.$myrow['jobid'].',\''.$table.'\',\''.$page.'\')" class="btn btn-success btn-sm"><i class="fa fa-pause"></i>&nbsp;暂停</a>';
	}
	echo '<br/><a href="#" onclick="job_edit(\'del\','.$myrow['jobid'].',\''.$table.'\',\''.$page.'\')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp;删除</a></div></td></tr>';
}
?>
	</tbody>
</table>
</div>

<?php
echo '<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="index.php?mod=admin-job&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="index.php?mod=admin-job&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="index.php?mod=admin-job&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="index.php?mod=admin-job&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="index.php?mod=admin-job&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="index.php?mod=admin-job&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo '</ul>';
#分页

}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>