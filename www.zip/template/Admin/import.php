<?php
if(!defined('IN_CRONLITE'))exit();
$title="批量导入QQ";
$breadcrumb='<li><a href="index.php?mod=user"><i class="icon fa fa-home"></i>首页</a></li>
<li><a href="index.php?mod=qqlist"><i class="icon fa fa-qq"></i>ＱＱ管理</a></li>
<li class="active"><a href="#"><i class="icon fa fa-list-alt"></i>批量导入QQ</a></li>';
include TEMPLATE_ROOT."head.php";

$my=isset($_POST['my'])?$_POST['my']:$_GET['my'];
echo '<div class="col-lg-8 col-sm-10 col-xs-12 center-block" role="main">';
if ($isadmin==1)
{

if($_POST['type']=="edit"){
	$list = $_POST['list'];
	$list = str_replace(array("\r\n", "\r", "\n"), "[br]", $list);
	$match=explode("[br]",$list);
	$success=0;$error=0;
	foreach($match as $val){
		if($val=='')continue;
		$array=explode('----',$val);
		$qq=daddslashes($array[0]);
		$qpwd=daddslashes($array[1]);
		if($qq==''||$qpwd=='')continue;
		$qpwd=authcode($qpwd,'ENCODE',SYS_KEY);
		$rowm1=$DB->get_row("SELECT * FROM ".DBQZ."_qq WHERE qq='{$qq}' limit 1");
		if(!$rowm1['qq']){
			$sql = "INSERT INTO `".DBQZ."_qq`(`uid`,`qq`,`pw`,`status`,`status2`,`time`) VALUES ('{$uid}','{$qq}','{$qpwd}','0','0','{$date}')";
			$sds=$DB->query($sql);
			if($sds){
				$data='a:1:{s:6:"forbid";s:0:"";}';
				if($_POST['addzan']==1)
					$DB->query("insert into `".DBQZ."_qqjob` (`uid`,`qq`,`type`,`sign`,`method`,`data`,`lasttime`,`nexttime`,`pl`,`start`,`stop`,`sysid`) values ('{$uid}','{$qq}','zan','0','3','{$data}','".time()."','".time()."','0','0','24','1')");
				$success++;
			}else{
				$error++;
			}
		}else{
			$sql="update `".DBQZ."_qq` set `pw` ='$qpwd',`status` ='0',`status2` ='0',`time`='$date' where `qq`='$qq'";
			$sds=$DB->query($sql);
		}
		unset($sds);
	}
	exit("<script language=\"javascript\">alert('已成功导入{$success}个QQ，失败{$error}个');history.go(-1);</script>");
}
?>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">批量导入QQ</h3></div><div class="panel-body">
<form action="index.php?mod=import" method="post">
<input type="hidden" name="type" value="edit" />
<div class="form-group">
<label>QQ列表:</label><br>
<textarea class="form-control" name="list" rows="8" placeholder="一行一个，格式：QQ----密码" required></textarea>
</div>
<div class="form-group">
<input type="checkbox" name="addzan" id="addzan" value="1">
<label for="addzan">同时添加秒赞任务</label>
</div>
<div class="form-group text-right">
<button type="submit" class="btn btn-primary btn-block" id="save">提交</button>
</div>
</form>
<h5>说明:</h5>
使用之前请开启自动打码，可以增加newsid.php的刷新频率来快速更新QQ状态
</div></div>
<?php
}
else
{
showmsg('后台管理登录失败。请以管理员身份 <a href="index.php?mod=login">重新登录</a>！',3);
}
include TEMPLATE_ROOT."foot.php";
?>