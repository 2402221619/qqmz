<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title><?php echo $conf['sitename'].$conf['sitetitle']?></title>		
    <meta name="description" content="<?php echo $conf['description']?>">
    <meta name="keywords" content="<?php echo $conf['keywords']?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="images/favicon.ico">
    <!-- Bootstrap Core CSS -->
    <link href="assets/Chihiro/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
	<link rel="stylesheet" href="assets/Chihiro/css/reset.css"> <!-- CSS reset -->
    <link rel="stylesheet" href="assets/Chihiro/css/style.css">
	<link rel="stylesheet" href="assets/Chihiro/css/animated-logo.min.css"><!-- Logo -->
	<link rel="stylesheet" href="assets/Chihiro/css/our-team.css"> <!-- Resource style -->
	<!-- Custom Fonts -->
    <link href="assets/Chihiro/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<!-- Js -->
	<script src="assets/Chihiro/js/modernizr.js"></script> <!-- Modernizr -->
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="assets/Chihiro/js/html5shiv.js"></script>
        <script src="assets/Chihiro/js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
	<!-- /////////////////////////////////////////Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" style="background-color: rgba(0,0,0,.4);box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);padding: 5px 0;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <a class="navbar-brand page-scroll" href="#page-top"><?php echo $conf['sitename']?></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
					<li>
                        <a class="page-scroll" href="#page-top">首页</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">特点</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#team">微语</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">功能</a>
                    </li>
					<li>
                        <a class="page-scroll" href="#qqq">展示</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">关于</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	<!-- Navigation -->

	<!-- /////////////////////////////////////////Header -->
	<header id="page-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="o-container">
						<div class="c-slack">
						  <span class="c-slack__dot c-slack__dot--a"></span>
						  <span class="c-slack__dot c-slack__dot--b"></span>
						  <span class="c-slack__dot c-slack__dot--c"></span>
						  <span class="c-slack__dot c-slack__dot--d"></span>
						</div>
					</div>
					<div class="intro-text">
						<div class="intro-lead-in">免费提供24H离线秒赞秒评</div>
						<div class="intro-heading">本站功能一键开启,无需安装软件,电脑,平板,手机全部一站式通用!</div>
					</div>
					<?php if($islogin==1){?>
					<a class="btn btn-1 btn-sm" href="index.php?mod=user">用户中心</a>
					<?php }else{?>
					<a class="btn btn-1 btn-sm" href="index.php?mod=login">登录</a>
					<a class="btn btn-1 btn-sm" href="index.php?mod=reg">注册</a>
					<?php }?>
				</div>
			</div>
		</div>
    </header>
	<!-- Header -->
	
	<!-- /////////////////////////////////////////Content -->
	<div id="page-content" class="index-page">
		
		<!-- ////////////Content Box 01 -->
		<section id="services" class="box-content box-1">
			<div class="container">
				<div class="row">
					<div class="col-sm-3 box-item">
						<div class="wrap-img">
							<img src="assets/Chihiro/images/Html.png" />
						</div>
						<h3 class="blue">一站式管理</h3>
						<p>使用网站进行挂机，无需安装任何软件，注册登陆后添加QQ即可正常运行，您可以随时在电脑/手机/平板登陆本站进行功能设置</p>
						
					</div>
					<div class="col-sm-3 box-item">
						<div class="wrap-img">
							<img src="assets/Chihiro/images/CSS.png" />
						</div>
						<h3 class="yellow">分布式架构</h3>
						<p>高配置服务器采用分布式监控系统的运行，24小时不间断稳定不宕机，服务器秒级切换更改随心，离线托管完美使用体验</p>
						
					</div>
					<div class="col-sm-3 box-item">
						<div class="wrap-img">
							<img src="assets/Chihiro/images/screen.png" />
						</div>
						<h3 class="red">智能提醒服务</h3>
						<p>SID/KEY过期后邮件自动推送，AE微客使用付费邮局进行发信，保证邮件的送达率，让您秒赞24小时正常运行一切由我们来操作</p>
						
					</div>
					<div class="col-sm-3 box-item">
						<div class="wrap-img">
							<img src="assets/Chihiro/images/Setting.png" />
						</div>
						<h3 class="green">各种实用小工具</h3>
						<p>秒赞检测，单向好友检测，帮你一键找出单向好友，说说刷队形，说说刷赞，一键圈圈赞，让你爱不释手。</p>
						
					</div>
				</div>		
			</div>
		</section>
		
		<!-- ////////////Content Box 02 -->
		<section id="team" class="box-content box-4 box-style">
			<div class="clearfix"style="    width: 60%;margin: 0 auto;">
				<div class="cd-testimonials-wrapper cd-container">
					<ul class="cd-testimonials">
						<li>
							<p>24H秒赞、挂Q功能本平台免费使用，操作简单无需安装软件，安卓/苹果IOS通用，VIP会员服务全网最具性价比，功能全面为您秒赞好友说说，不漏掉每一条动态，为您秒评论好友说说，让Ta时时刻刻感受到你的存在，增加您和好友的亲密度</p>

						</li>
						<li>
							<p>多功能、双协议，24小时稳定运行，无需安装软件，操作简单快速上手，已研发QS点赞协议保证不漏赞，采用高配置独立服务器，极速秒赞，全天24小时监控执行，完美离线使用。</p>

						</li>
						<li>
							<p>我们始终坚持以用户需求为导向，为追求用户体验设计，提供最完善的秒赞服务，我们将不断地超越自我，挑战自我！</p>

						</li>
					</ul> <!-- cd-testimonials -->	
				</div> <!-- cd-testimonials-wrapper -->
				

			</div>
		</section>
		
		<!-- ////////////Content Box 03 -->
		<section id="about" class="box-content box-3">
			<div class="container">
				<div class="row heading">
					<div class="col-lg-12">
						<h2>功能介绍</h2>
						<hr>
						
					</div>
				</div>
				<div class="col-md-6 contact-form wow animated fadeInLeft animated" style="visibility: visible;">
						<address class="contact-details">
							<h3>如何使用？</h3>						
							<div class="vertical-timeline-block">
                              <p>在用户界面中添加需要托管的QQ号，之后点击开启秒赞功能即可离线运行，无需一直开着网页，任务会24小时自动运行。</p><br>
                              <p>更有全网独家的配套图文说说系统，多种语录可以选择，文字与图片配套，全天24小时自动发表，让你的小伙伴羡慕嫉妒去吧！</p><br>
                             <p>全新的QQ等级代挂功能只需提交QQ即可每天满加速，快速升级QQ等级到皇冠不再是梦。</p>
						</div></address>
					</div>
					
					<div class="col-md-6 wow animated fadeInRight animated" style="visibility: visible;">
						<address class="contact-details">
							<h3>拥有的功能</h3>						
							<div class="aini">
							<a title="秒赞">秒赞</a>
							<a title="秒评">秒评</a>
							<a title="离线挂Q">离线挂Q</a>
							<a title="包月转发说说">转发说说</a>
							<a title="平台互刷留言">互刷留言</a>
							<a title="刷访问量">刷访问量</a>
							<a title="刷主页赞">刷主页赞</a>
							<a title="自动空间签到">空间签到</a>
							<a title="每日自动浇花">自动浇花</a>
							<a title="快速清理留言">快速清理留言</a>
							<a title="定时删除说说">定时删除说说</a>
							<a title="图书签到">图书签到</a>
							<a title="QQ会员多项签到">QQ会员多项签到</a>
							<a title="QQ钱包签到">QQ钱包签到</a>
                            <a title="QQ群签到">QQ群签到</a>
							<a title="绿钻签到">绿钻签到</a>
							<a title="说说圈图">说说圈图</a>
							<a title="单向好友检测">单向好友检测</a>
							<a title="秒赞好友检测">秒赞好友检测</a>
							<a title="刷圈圈赞99">刷圈圈赞99+</a>
							<a title="说说刷赞">说说刷赞</a>
                            <a title="全套QQ等级代挂">全套QQ等级代挂</a>
                            </div>
                            
						</address>
					</div>
				</div>		
			</div>
		</section>
		
		<!-- ////////////Content Box 04 -->
		<section id="qqq" class="box-content box-4 box-style">
			<div class="container">
				<div class="row heading">
					<div class="col-lg-12">
	                    <h2>最新添加的QQ</h2>
						<hr>
	                </div>
				</div>
				<?php //获取最新QQ列表
$liukay=$DB->query("select qq,time from ".DBQZ."_qq order by id desc limit 24");
while ($lingku = $DB->fetch($liukay))
{
echo '<div class="col-xs-3 col-md-2 col-lg-1"><a href="./index.php?mod=search&q='.$lingku['qq'].'" target="_blank"><img class="qqlogo"  src="http://q1.qlogo.cn/g?b=qq&nk='.$lingku['qq'].'&s=100" width="80px" height="80px" alt="'.$lingku['qq'].'" title="'.$lingku['qq'].'|添加时间:'.$lingku['time'].'"></a></div>';
}
?>
			</div>
		</section>
		
		<!-- ////////////Content Box 05 -->
		<section class="box-content box-5" id="contact">
			<div class="container">
				<div class="row heading">
					<div class="col-lg-12">
	                    <h2>关于平台</h2>
						<hr>
	                </div>
				</div>
					<div class="col-md-6 contact-form wow animated fadeInLeft animated" style="visibility: visible;">
						<address class="contact-details">
							<h3>秒赞介绍</h3>						
							<p>本站采用阿里云集群高配置服务器24H不间断处理秒赞服务，保证了秒赞服务的稳定和可靠性，到目前已经有许多用户选择了<?php echo $conf['sitename']?>，这是为什么？因为我们提供最全面的功能体验，优质稳定的服务，并且我们的信誉有保障，保证你的账号安全不泄露！选择<?php echo $conf['sitename']?>，才是你最好的选择，欢迎免费进行体验！
                            </p>
						</address>
					</div>
					
					<div class="col-md-6 wow animated fadeInRight animated" style="visibility: visible;">
						<address class="contact-details">
							<h3>联系我们</h3>						
							<p><i class="fa fa-pencil"></i><?php echo $conf['sitename']?><span><?php echo $siteurl?></span>
                            </p><br>
							<p><i class="fa fa-phone"></i>站长QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" target="_blank"><?php echo $conf['kfqq']?></a></p>
							<p><i class="fa fa-envelope"></i><?php echo $conf['kfqq']?>@qq.com</p>
						</address>
					</div>
			</div>
		</section>
		
	</div>
	
	<!-- /////////////////////////////////////////Footer -->
	<footer>
		<div class="wrap-footer">
			<div class="container">
				<div class="row">
					<div class="footer-content" style="margin: 0 auto;">
						<div class="wow animated fadeInDown animated" style="visibility: visible;">
							<p><?php echo $conf['sitename']?></p>
							<p>免费24H离线秒赞秒评系统</p>
						</div>
						<p>Copyright © 2015-2016 <a href="<?php echo $siteurl?>" title="<?php echo $conf['sitename']?>"><?php echo $conf['sitename']?></a></p>
                        <!--p><a  href="http://www.miitbeian.gov.cn/"  target="_blank">备案号</a></p-->
					</div>
				</div>
			</div>
		</div>

	</footer>
	<!-- Footer -->
	<!-- jQuery -->
	<script src="assets/Chihiro/js/jquery-2.1.1.js"></script>
	<script src="assets/Chihiro/js/masonry.pkgd.min.js"></script>
	<script src="assets/Chihiro/js/jquery.flexslider-min.js"></script>
	<script src="assets/Chihiro/js/main.js"></script> <!-- Resource jQuery -->
	<!-- Bootstrap Core JavaScript -->
	<script src="assets/Chihiro/js/bootstrap.min.js"></script>
	<!-- Custom Theme JavaScript -->
	<script src="assets/Chihiro/js/agency.js"></script>
	<!-- Animated Top -->
	<script src="assets/Chihiro/js/jquery.easing.min.js"></script>
	<script src="assets/Chihiro/js/classie.js"></script>
	<script src="assets/Chihiro/js/cbpAnimatedHeader.js"></script>
	<?php if(!empty($conf['ui_backmusic'])){?>
<section class="u-audio hidden" data-src="<?php echo $conf['ui_backmusic']?>"></section>
<div class="btnAudio" id="btnAudio"></div>
 
<script>
var bg_audio_val = true;
var bg_audio = new Audio();
function audio_init(){
        var options_audio = {
                loop: true,
                preload: "auto",
                src: $('.u-audio').attr('data-src')
        }
        for (var key in options_audio) {
                bg_audio[key] = options_audio[key];
        }
        bg_audio.load();
        audio_addEvent();
        bg_audio.play();
}
function audio_addEvent(){
        $("#btnAudio").on('click', audio_control);
        $(bg_audio).on('play',function(){
                bg_audio_val = false;
                $('#btnAudio').addClass('rotate1circle');
        })
        $(bg_audio).on('pause',function(){
                $('#btnAudio').removeClass('rotate1circle');
        })
}
function audio_control(){
        if(!bg_audio_val){
                bg_audio.pause();
                bg_audio_val = true;
        }else{
                bg_audio.play();
        }
}
audio_init();
</script>
<?php }?>
</body>
</html>